import 'react-native-gesture-handler';
import { NavigationContainer, DefaultTheme, DarkTheme, getFocusedRouteNameFromRoute } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { StatusBar } from 'expo-status-bar';
import { View, ActivityIndicator, StyleSheet } from 'react-native';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';

import { AuthProvider, useAuth } from './src/context/AuthContext';
import { ThemeProvider, useThemeSettings } from './src/context/ThemeContext';
import { AppLockProvider, useAppLock } from './src/context/AppLockContext';
import { CallProvider } from './src/context/CallContext';
import LockScreen from './src/components/LockScreen';
import { Colors } from './src/theme';
import { Icon, IconName } from './src/components/Icon';
import { QueryProvider } from './src/providers/QueryProvider';
import { OfflineIndicator } from './src/components/OfflineIndicator';

import WelcomeScreen from './src/screens/WelcomeScreen';
import LoginScreen from './src/screens/LoginScreen';
import OTPScreen from './src/screens/OTPScreen';
import NameEntryScreen from './src/screens/NameEntryScreen';
import UserInfoScreen from './src/screens/UserInfoScreen';
import ContactScreen from './src/screens/ContactScreen';

import HomeScreen from './src/screens/HomeScreen';
import PostDetailScreen from './src/screens/PostDetailScreen';
import ComposeScreen from './src/screens/ComposeScreen';
import SearchScreen from './src/screens/SearchScreen';
import NotificationsScreen from './src/screens/NotificationsScreen';
import ChatsScreen from './src/screens/ChatsScreen';
import ChatScreen from './src/screens/ChatScreen';
import GroupChatScreen from './src/screens/GroupChatScreen';
import GroupsScreen from './src/screens/GroupsScreen';
import ProfileScreen from './src/screens/ProfileScreen';
import ProfileEditScreen from './src/screens/ProfileEditScreen';
import SettingsScreen from './src/screens/SettingsScreen';
import SecurityScreen from './src/screens/SecurityScreen';
import PINSecurityScreen from './src/screens/PINSecurityScreen';
import FaceIDScreen from './src/screens/FaceIDScreen';
import TouchIDScreen from './src/screens/TouchIDScreen';
import TermsScreen from './src/screens/TermsScreen';
import UserProfileScreen from './src/screens/UserProfileScreen';
import AdminDashboard from './src/screens/AdminDashboard';
import KeyBackupScreen from './src/screens/KeyBackupScreen';
import PrivacySettingsScreen from './src/screens/PrivacySettingsScreen';
import { I18nProvider } from './src/i18n';
import BlockedUsersScreen from './src/screens/BlockedUsersScreen';
import DeleteAccountScreen from './src/screens/DeleteAccountScreen';
import HashtagScreen from './src/screens/HashtagScreen';
import GroupInvitesScreen from './src/screens/GroupInvitesScreen';

const AuthStack = createStackNavigator();
const RootStack = createStackNavigator();
const HomeStack = createStackNavigator();
const MessagesStack = createStackNavigator();
const ProfileStack = createStackNavigator();
const Tabs = createBottomTabNavigator();

const mkTheme = (base: typeof DefaultTheme, c: typeof Colors.light) => ({
  ...base,
  colors: { ...base.colors, background: c.background, card: c.background, text: c.text, border: c.border, primary: c.primary },
});
const LightNavTheme = mkTheme(DefaultTheme, Colors.light);
const DarkNavTheme = mkTheme(DarkTheme, Colors.dark);

const noHeader = { headerShown: false };

const HomeStackScreen = () => (
  <HomeStack.Navigator screenOptions={noHeader}>
    <HomeStack.Screen name="Feed" component={HomeScreen} />
    <HomeStack.Screen name="PostDetail" component={PostDetailScreen} />
  </HomeStack.Navigator>
);

const MessagesStackScreen = () => (
  <MessagesStack.Navigator screenOptions={noHeader}>
    <MessagesStack.Screen name="ChatsList" component={ChatsScreen} />
    <MessagesStack.Screen name="Chat" component={ChatScreen} />
    <MessagesStack.Screen name="GroupChat" component={GroupChatScreen} />
    <MessagesStack.Screen name="ContactScreen" component={ContactScreen} />
  </MessagesStack.Navigator>
);

const ProfileStackScreen = () => (
  <ProfileStack.Navigator screenOptions={noHeader}>
    <ProfileStack.Screen name="ProfileHome" component={ProfileScreen} />
    <ProfileStack.Screen name="ProfileEdit" component={ProfileEditScreen} />
    <ProfileStack.Screen name="Settings" component={SettingsScreen} />
    <ProfileStack.Screen name="Security" component={SecurityScreen} />
    <ProfileStack.Screen name="PINSecurity" component={PINSecurityScreen} />
    <ProfileStack.Screen name="FaceID" component={FaceIDScreen} />
    <ProfileStack.Screen name="TouchID" component={TouchIDScreen} />
    <ProfileStack.Screen name="Terms" component={TermsScreen} />
    <ProfileStack.Screen name="AdminDashboard" component={AdminDashboard} />
  </ProfileStack.Navigator>
);

const TAB_ICONS: Record<string, [IconName, IconName]> = {
  Home: ['home', 'homeFill'],
  Search: ['search', 'search'],
  Notifications: ['bell', 'bellFill'],
  Messages: ['mail', 'mailFill'],
  Groups: ['users', 'usersFill'],
  Profile: ['user', 'userFill'],
};

// screens inside a tab that should hide the tab bar (full-screen chat UIs)
const HIDE_TABBAR = ['Chat', 'GroupChat', 'ContactScreen', 'PostDetail', 'ProfileEdit', 'Settings', 'PrivacySettings', 'Security', 'PINSecurity', 'FaceID', 'TouchID', 'Terms', 'AdminDashboard', 'GroupDetail', 'GroupMembers', 'GroupSettings'];

const MainTabs = () => {
  const { darkMode } = useThemeSettings();
  const c = darkMode ? Colors.dark : Colors.light;
  const insets = useSafeAreaInsets();
  return (
    <Tabs.Navigator
      screenOptions={({ route }) => {
        const focused = getFocusedRouteNameFromRoute(route) ?? '';
        const hide = HIDE_TABBAR.includes(focused);
        return {
          headerShown: false,
          tabBarShowLabel: false,
          tabBarActiveTintColor: c.primary,
          tabBarInactiveTintColor: c.textMuted,
          tabBarStyle: {
            display: hide ? 'none' : 'flex',
            backgroundColor: c.card,
            borderTopWidth: 0,
            borderTopLeftRadius: 26,
            borderTopRightRadius: 26,
            height: 58 + insets.bottom,
            paddingTop: 8,
            shadowColor: '#000',
            shadowOpacity: darkMode ? 0.5 : 0.1,
            shadowRadius: 14,
            shadowOffset: { width: 0, height: -4 },
            elevation: 12,
          },
          tabBarIcon: ({ focused: f, color }: { focused: boolean; color: string }) => {
            const [off, on] = TAB_ICONS[route.name];
            return <Icon name={f ? on : off} size={26} color={color} strokeWidth={f ? 2.3 : 1.8} />;
          },
        };
      }}
    >
      <Tabs.Screen name="Home" component={HomeStackScreen} />
      <Tabs.Screen name="Search" component={SearchScreen} />
      <Tabs.Screen name="Notifications" component={NotificationsScreen} />
      <Tabs.Screen name="Messages" component={MessagesStackScreen} />
      <Tabs.Screen name="Groups" component={GroupsScreen} />
      <Tabs.Screen name="Profile" component={ProfileStackScreen} />
    </Tabs.Navigator>
  );
};

function RootNavigator() {
  const { token, loading } = useAuth();
  const { locked, ready } = useAppLock();
  const { darkMode } = useThemeSettings();
  const c = darkMode ? Colors.dark : Colors.light;

  if (loading || !ready) {
    return (
      <View style={[styles.splash, { backgroundColor: c.background }]}>
        <ActivityIndicator size="large" color={c.primary} />
      </View>
    );
  }

  return (
    <NavigationContainer theme={darkMode ? DarkNavTheme : LightNavTheme}>
      <StatusBar style={darkMode ? 'light' : 'dark'} />
      {token ? (
        <RootStack.Navigator screenOptions={noHeader}>
          <RootStack.Screen name="Main" component={MainTabs} />
          <RootStack.Screen name="UserProfile" component={UserProfileScreen} />
          <RootStack.Screen name="Hashtag" component={HashtagScreen} />
          <RootStack.Screen name="KeyBackup" component={KeyBackupScreen} />
          <RootStack.Screen name="PrivacySettings" component={PrivacySettingsScreen} />
          <RootStack.Screen name="BlockedUsers" component={BlockedUsersScreen} />
          <RootStack.Screen name="DeleteAccount" component={DeleteAccountScreen} />
          <RootStack.Screen name="GroupInvites" component={GroupInvitesScreen} />
          <RootStack.Screen name="Compose" component={ComposeScreen} options={{ presentation: 'modal' }} />
        </RootStack.Navigator>
      ) : (
        <AuthStack.Navigator screenOptions={noHeader}>
          <AuthStack.Screen name="Welcome" component={WelcomeScreen} />
          <AuthStack.Screen name="Login" component={LoginScreen} />
          <AuthStack.Screen name="OTP" component={OTPScreen} />
          <AuthStack.Screen name="NameEntryScreen" component={NameEntryScreen} />
          <AuthStack.Screen name="UserInfo" component={UserInfoScreen} />
        </AuthStack.Navigator>
      )}
      <OfflineIndicator />
      {locked ? <LockScreen /> : null}
    </NavigationContainer>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <QueryProvider>
        <ThemeProvider>
         <I18nProvider>
          <AuthProvider>
            <AppLockProvider>
              <CallProvider>
                <RootNavigator />
              </CallProvider>
            </AppLockProvider>
          </AuthProvider>
         </I18nProvider>
        </ThemeProvider>
      </QueryProvider>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  splash: { flex: 1, justifyContent: 'center', alignItems: 'center' },
});
