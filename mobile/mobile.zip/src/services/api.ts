import axios, { AxiosInstance } from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { API_URL } from '../config';

const api: AxiosInstance = axios.create({ baseURL: API_URL, timeout: 15000 });

let onUnauthorized: (() => void) | null = null;
export const setUnauthorizedHandler = (fn: () => void) => {
  onUnauthorized = fn;
};

api.interceptors.request.use(async (config) => {
  const token = await AsyncStorage.getItem('echat_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (res) => res,
  (err) => {
    const url = err.config?.url || '';
    const isAuthCall = url.startsWith('/auth/');
    if (err.response?.status === 401 && !isAuthCall && onUnauthorized) {
      onUnauthorized();
    }
    return Promise.reject(err);
  }
);

export interface SignupData {
  name: string;
  email: string;
  password: string;
}

export interface LoginData {
  email: string;
  password: string;
}

export interface OTPOptions {
  phone: string;
  code?: string;
}

export interface AuthUser {
  id: number | string;
  name: string;
  username?: string | null;
  email?: string | null;
  phone?: string | null;
  avatar?: string | null;
  bio?: string | null;
  is_admin?: boolean;
  is_private?: boolean;
  public_key?: string | null;
}

export interface MessageFile {
  url: string;
  name: string;
  size: number;
}

export interface Conversation {
  id: string | number;
  name?: string;
  type?: 'direct' | 'group';
  avatar?: string | null;
  group_id?: number | string | null;
  pinned?: boolean;
  muted?: boolean;
  archived?: boolean;
  pinned_message?: { id: string | number; content: string; type: string; sender_name?: string } | null;
  disappear_after?: number | null;
  unread_count?: number;
  participants?: Array<{ id: string | number; name?: string; username?: string | null; avatar?: string | null; status?: string; last_seen?: string | null; public_key?: string | null }>;
  last_message?: string;
  last_message_type?: 'text' | 'image' | 'file' | 'voice';
  last_message_at?: string;
  last_message_sender_id?: number | string;
}

export interface Message {
  id: string | number;
  conversation_id: string | number;
  sender_id: string | number;
  content: string;
  type?: 'text' | 'image' | 'file' | 'voice';
  file_url?: string;
  file_uri?: string;
  file_name?: string;
  file_size?: number;
  voice_duration?: string;
  voice_waveform?: string | null;
  sender_name?: string;
  sender_avatar?: string | null;
  status?: 'sending' | 'sent' | 'delivered' | 'read';
  created_at: string;
  edited_at?: string | null;
  read_at?: string;
  reactions?: MessageReaction[];
  reply?: MessageReply | null;
  forwarded?: boolean;
  view_once?: boolean;
  opened?: boolean;
  expires_at?: string | null;
  /** client only: decrypted text of an end-to-end encrypted message */
  plain?: string;
}

export interface MessageReply {
  id: string | number;
  deleted?: boolean;
  content?: string;
  type?: string;
  sender_id?: string | number;
  sender_name?: string;
}

export interface Reaction {
  emoji: string;
  count: number;
  user_id: string | number;
  user_name?: string;
  user_avatar?: string;
  created_at?: string;
  my_reaction?: boolean;
}

export interface MessageReaction {
  emoji: string;
  count: number;
  users: Array<{ id: string | number; name: string; avatar?: string }>;
  my_reaction?: boolean;
}

export interface User {
  id: string | number;
  name: string;
  email?: string;
  phone?: string;
  username?: string | null;
  avatar?: string | null;
  bio?: string | null;
  status?: string;
}

export const auth = {
  signup: (data: SignupData) => api.post('/auth/signup', data),
  login: (data: LoginData) => api.post('/auth/login', data),
  sendOTP: (data: { phone: string }) => api.post('/auth/send-otp', data),
  resendOTP: (data: { phone: string }) => api.post('/auth/resend-otp', data),
  verifyOTP: (data: OTPOptions) => api.post('/auth/verify-otp', data),
  // registrationToken comes from verify-otp for phone numbers that have no account yet
  setName: (data: { registrationToken: string; name: string }) => api.post('/auth/set-name', data),
  logout: () => api.post('/auth/logout'),
  pushRegister: (data: { token: string }) => api.post('/auth/push/register', data),
};

export interface UserSettings {
  hide_presence: boolean;
  read_receipts: boolean;
  who_can_message: 'everyone' | 'followed' | 'nobody';
  notif: { like: boolean; comment: boolean; follow: boolean; mention: boolean; message: boolean; group: boolean };
  quiet: { enabled: boolean; start: number; end: number; tz?: number };
}

export const users = {
  list: () => api.get<User[]>('/users'),
  get: (id: string | number) => api.get<User>(`/users/${id}`),
  me: () => api.get<AuthUser>('/users/me'),
  updateMe: (data: { name?: string; bio?: string; username?: string; is_private?: boolean }) => api.put<AuthUser>('/users/me', data),
  getSettings: () => api.get<UserSettings>('/users/me/settings'),
  putSettings: (data: Partial<UserSettings>) => api.put<UserSettings>('/users/me/settings', data),
  getKeyBackup: () => api.get<{ backup: string }>('/users/me/key-backup'),
  putKeyBackup: (backup: string) => api.put('/users/me/key-backup', { backup }),
  setPublicKey: (public_key: string) => api.put('/users/me/key', { public_key }),
  lookupPhones: (phones: string[]) => api.post<Array<User & { phone_tail: string }>>('/users/lookup-phones', { phones }),
  updateAvatar: (formData: FormData) =>
    api.put('/users/avatar', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
      transformRequest: (data) => data,
    }),
};

export const conversations = {
  list: () => api.get<Conversation[]>('/conversations'),
  get: (id: string | number) => api.get<Conversation>(`/conversations/${id}`),
  create: (data: { name?: string; type: string; participantIds: Array<string | number> }) =>
    api.post<Conversation>('/conversations', data),
  pin: (id: string | number) => api.put<Conversation>(`/conversations/${id}/pin`),
  messages: (id: string | number, limit?: number, offset?: number) =>
    api.get<{ messages: Message[]; hasMore: boolean }>(`/conversations/${id}/messages`, { params: { limit, offset } }),
  search: (id: string | number, q: string) => api.get<{ messages: Message[] }>(`/conversations/${id}/search`, { params: { q } }),
  /** hours: -1 = until turned off, 0 = unmute */
  archive: (id: string | number) => api.put<Conversation>(`/conversations/${id}/archive`),
  pinMessage: (id: string | number, messageId: string | number | null) => api.put(`/conversations/${id}/pin-message`, { message_id: messageId }),
  mute: (id: string | number, hours: number) => api.put<Conversation>(`/conversations/${id}/mute`, { hours }),
  disappearing: (id: string | number, seconds: number) => api.put<Conversation>(`/conversations/${id}/disappearing`, { seconds }),
};

export const messages = {
  send: (data: { conversation_id: string | number; content: string; reply_to?: string | number }) =>
    api.post<Message>('/messages', data),
  upload: (data: { conversation_id: string | number; file: any; reply_to?: string | number; voice_duration?: string; voice_waveform?: string; view_once?: boolean }) => {
    const formData = new FormData();
    if (data.view_once) formData.append('view_once', '1');
    formData.append('conversation_id', String(data.conversation_id));
    if (data.reply_to) formData.append('reply_to', String(data.reply_to));
    if (data.voice_duration) formData.append('voice_duration', data.voice_duration);
    if (data.voice_waveform) formData.append('voice_waveform', data.voice_waveform);
    formData.append('file', {
      uri: data.file.uri,
      type: data.file.type || 'image/jpeg',
      name: data.file.name || 'image.jpg',
    } as any);
    return api.post<Message>('/messages/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
      transformRequest: (data) => data,
    });
  },
  openViewOnce: (id: string | number) => api.post<{ file_url: string }>(`/messages/${id}/open`),
  schedule: (conversation_id: string | number, content: string, send_at: string) =>
    api.post<{ id: number; send_at: string }>('/messages/schedule', { conversation_id, content, send_at }),
  scheduled: (conversation_id: string | number) =>
    api.get<Array<{ id: number; content: string; send_at: string }>>('/messages/scheduled', { params: { conversation_id } }),
  cancelScheduled: (id: number) => api.delete(`/messages/scheduled/${id}`),
  translate: (text: string, to: string) => api.get<{ translation: string }>('/translate', { params: { text, to } }),
  markDelivered: (id: string | number) => api.put(`/messages/${id}/delivered`),
  markRead: (id: string | number) => api.put(`/messages/${id}/read`),
  markAllRead: (conversationId: string | number) =>
    api.put(`/messages/conversation/${conversationId}/read-all`),
  getReactions: (messageId: string | number) =>
    api.get<MessageReaction[]>(`/messages/${messageId}/reactions`),
  addReaction: (messageId: string | number, emoji: string) =>
    api.post(`/messages/${messageId}/reactions`, { emoji }),
  removeReaction: (messageId: string | number, emoji: string) =>
    api.delete(`/messages/${messageId}/reactions/${encodeURIComponent(emoji)}`),
  editMessage: (messageId: string | number, content: string) =>
    api.put<Message>(`/messages/${messageId}`, { content }),
  deleteMessage: (messageId: string | number, scope: 'me' | 'all' = 'all') =>
    api.delete(`/messages/${messageId}`, { params: { scope } }),
  forward: (messageId: string | number, targets: Array<{ conversation_id: string | number; content?: string }>) =>
    api.post<{ messages: Message[] }>(`/messages/${messageId}/forward`, { targets }),
};

export default api;

export const safety = {
  block: (userId: string | number) => api.post<{ blocked: boolean }>(`/safety/block/${userId}`),
  blocks: () => api.get<User[]>('/safety/blocks'),
  report: (type: 'user' | 'post' | 'comment' | 'message' | 'story', id: string | number, reason: string, details?: string) =>
    api.post('/safety/report', { type, id: Number(id), reason, details }),
  exportData: () => api.get('/safety/export'),
  deleteAccount: () => api.delete('/safety/account', { data: { confirm: 'DELETE' } }),
};
