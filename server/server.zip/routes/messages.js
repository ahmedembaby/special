const express = require('express');
const path = require('path');
const pool = require('../db');
const upload = require('../middleware/upload');
const rt = require('../services/realtime');
const { pushToUsers } = require('../services/push');
const { isBlockedBetween } = require('../utils/blocks');
const { isParticipant, participantIds, MESSAGE_SELECT, visible, attachReactions, getMessage } = require('../services/chat');
const { toInt } = require('../utils/format');

const router = express.Router();

const messageTypeFor = (mime = '', name = '') => {
  const m = mime.toLowerCase();
  const ext = path.extname(name).toLowerCase();
  if (m.startsWith('image/')) return 'image';
  if (m.startsWith('audio/') || ['.m4a', '.aac', '.caf', '.3gp', '.mp3', '.wav', '.ogg'].includes(ext)) return 'voice';
  return 'file';
};

const isEncrypted = (c) => typeof c === 'string' && c.startsWith('e2ee:');
const preview = (msg) => (msg.type === 'text' ? (isEncrypted(msg.content) ? '🔒 New message' : msg.content) : msg.type === 'image' ? '📷 Photo' : msg.type === 'voice' ? '🎤 Voice message' : '📎 File');

// Saves the message, fans it out over sockets and sends push to people who are not connected
async function deliver(message, sender) {
  const ids = await participantIds(message.conversation_id);
  rt.emitToConversation(message.conversation_id, 'message_received', message);
  // Chat-list updates for every participant (even those not inside the conversation screen)
  rt.emitToUsers(ids, 'conversation_message', { conversation_id: message.conversation_id, message });
  const others = ids.filter((id) => id !== sender.id);
  // Somebody else is connected: the message has reached a device -> "delivered"
  if (others.some((id) => rt.isOnline(id))) {
    try {
      await pool.query("UPDATE messages SET status = 'delivered' WHERE id = ? AND status = 'sent'", [message.id]);
      rt.emitToConversation(message.conversation_id, 'message_delivered', { messageId: message.id, conversationId: message.conversation_id });
    } catch (e) { console.warn('delivered mark:', e.message); }
  }
  let offline = await pushAllowedIds(others.filter((id) => !rt.isOnline(id)));
  if (offline.length) {
    // people who muted this conversation get no push
    const [muted] = await pool.query(
      'SELECT user_id FROM conversation_participants WHERE conversation_id = ? AND user_id IN (?) AND muted_until IS NOT NULL AND muted_until > NOW()',
      [message.conversation_id, offline]
    );
    const mutedIds = new Set(muted.map((r) => r.user_id));
    offline = offline.filter((id) => !mutedIds.has(id));
  }
  if (offline.length) {
    pushToUsers(offline, {
      title: sender.name,
      body: preview(message),
      data: { type: 'message', conversationId: message.conversation_id },
    }).catch(() => {});
  }
}

const { pushAllowed } = require('../services/prefs');
const readReceiptsOn = async (userId) => { const [r] = await pool.query('SELECT read_receipts FROM users WHERE id = ?', [userId]); return !r[0] || r[0].read_receipts !== 0; };
const pushAllowedIds = (ids) => pushAllowed(ids, 'message');

// direct conversations: no messages when either side blocked the other, or the receiver limited who can write to them
async function blockedInDirect(conversationId, userId) {
  const [c] = await pool.query("SELECT type FROM conversations WHERE id = ?", [conversationId]);
  if (!c[0] || c[0].type !== 'direct') return false;
  const ids = await participantIds(conversationId);
  const other = ids.find((i) => i !== userId);
  if (!other) return false;
  if (await isBlockedBetween(userId, other)) return true;
  const [u] = await pool.query('SELECT who_can_message FROM users WHERE id = ?', [other]);
  const rule = u[0] && u[0].who_can_message;
  if (rule === 'nobody') return true;
  if (rule === 'followed') {
    // only people the receiver follows may write
    const [f] = await pool.query('SELECT 1 FROM follows WHERE follower_id = ? AND following_id = ?', [other, userId]);
    return f.length === 0;
  }
  return false;
}

// Disappearing messages: stamp the expiry when the conversation has a timer
async function applyExpiry(messageId, conversationId) {
  const [c] = await pool.query('SELECT disappear_after FROM conversations WHERE id = ?', [conversationId]);
  if (c[0] && c[0].disappear_after) {
    await pool.query('UPDATE messages SET expires_at = DATE_ADD(NOW(), INTERVAL ? SECOND) WHERE id = ?', [c[0].disappear_after, messageId]);
  }
}

// reply_to must be a message of the same conversation
async function validReplyTo(replyTo, conversationId) {
  const id = Number(replyTo);
  if (!id) return null;
  const [r] = await pool.query('SELECT id FROM messages WHERE id = ? AND conversation_id = ?', [id, conversationId]);
  return r.length ? id : null;
}

const loadSender = async (id) => {
  const [rows] = await pool.query('SELECT id, name FROM users WHERE id = ?', [id]);
  return rows[0];
};

// POST /api/messages  { conversation_id, content, reply_to? }
router.post('/', async (req, res) => {
  try {
    const conversationId = Number(req.body.conversation_id);
    const content = String(req.body.content || '').trim();
    if (!conversationId || !content) return res.status(400).json({ message: 'conversation_id and content are required' });
    if (content.length > 5000) return res.status(400).json({ message: 'Message is too long' });
    if (!(await isParticipant(conversationId, req.user.id))) return res.status(403).json({ message: 'Not a participant of this conversation' });
    if (await blockedInDirect(conversationId, req.user.id)) return res.status(403).json({ message: 'You cannot message this user' });

    const [r] = await pool.query(
      "INSERT INTO messages (conversation_id, sender_id, content, type, status, reply_to) VALUES (?, ?, ?, 'text', 'sent', ?)",
      [conversationId, req.user.id, content, await validReplyTo(req.body.reply_to, conversationId)]
    );
    await applyExpiry(r.insertId, conversationId);
    const message = await getMessage(r.insertId, req.user.id);
    deliver(message, await loadSender(req.user.id)).catch((e) => console.warn('deliver:', e.message));
    res.status(201).json(message);
  } catch (err) {
    console.error('send message:', err.message);
    res.status(500).json({ message: 'Could not send message' });
  }
});

// POST /api/messages/upload  multipart: conversation_id, file
router.post('/upload', upload.chat.single('file'), async (req, res) => {
  try {
    const conversationId = Number(req.body.conversation_id);
    if (!conversationId || !req.file) return res.status(400).json({ message: 'conversation_id and file are required' });
    if (!(await isParticipant(conversationId, req.user.id))) return res.status(403).json({ message: 'Not a participant of this conversation' });

    const type = messageTypeFor(req.file.mimetype, req.file.originalname);
    const url = `/uploads/chat/${req.file.filename}`;
    const [r] = await pool.query(
      `INSERT INTO messages (conversation_id, sender_id, content, type, file_url, file_name, file_size, voice_duration, voice_waveform, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'sent')`,
      [conversationId, req.user.id, '', type, url, req.file.originalname, req.file.size, req.body.voice_duration || null,
        type === 'voice' && /^[0-9]{10,64}$/.test(String(req.body.voice_waveform || '')) ? String(req.body.voice_waveform) : null]
    );
    if (type === 'image' && String(req.body.view_once) === '1') await pool.query('UPDATE messages SET view_once = 1 WHERE id = ?', [r.insertId]);
    const replyTo = await validReplyTo(req.body.reply_to, conversationId);
    if (replyTo) await pool.query('UPDATE messages SET reply_to = ? WHERE id = ?', [replyTo, r.insertId]);
    await applyExpiry(r.insertId, conversationId);
    const message = await getMessage(r.insertId, req.user.id);
    deliver(message, await loadSender(req.user.id)).catch((e) => console.warn('deliver:', e.message));
    res.status(201).json(message);
  } catch (err) {
    console.error('upload message:', err.message);
    res.status(500).json({ message: 'Could not send file' });
  }
});

// Loads a message the caller may access (is a participant of its conversation)
async function accessibleMessage(messageId, userId) {
  const [rows] = await pool.query('SELECT id, conversation_id, sender_id, type, status FROM messages WHERE id = ?', [messageId]);
  const m = rows[0];
  if (!m) return { error: 404 };
  if (!(await isParticipant(m.conversation_id, userId))) return { error: 403 };
  return { message: m };
}

const fail = (res, e) => res.status(e === 404 ? 404 : 403).json({ message: e === 404 ? 'Message not found' : 'Forbidden' });

router.put('/:id/delivered', async (req, res) => {
  try {
    const { message, error } = await accessibleMessage(req.params.id, req.user.id);
    if (error) return fail(res, error);
    if (message.sender_id !== req.user.id && message.status === 'sent') {
      await pool.query("UPDATE messages SET status = 'delivered' WHERE id = ? AND status = 'sent'", [message.id]);
      rt.emitToConversation(message.conversation_id, 'message_delivered', { messageId: message.id, conversationId: message.conversation_id, userId: req.user.id });
    }
    res.json({ message: 'ok' });
  } catch (err) {
    res.status(500).json({ message: 'Could not update message' });
  }
});

router.put('/:id/read', async (req, res) => {
  try {
    const { message, error } = await accessibleMessage(req.params.id, req.user.id);
    if (error) return fail(res, error);
    if (message.sender_id !== req.user.id && message.status !== 'read') {
      await pool.query("UPDATE messages SET status = 'read', read_at = NOW() WHERE id = ?", [message.id]);
      if (await readReceiptsOn(req.user.id)) rt.emitToConversation(message.conversation_id, 'message_read', { messageId: message.id, conversationId: message.conversation_id, userId: req.user.id });
    }
    res.json({ message: 'ok' });
  } catch (err) {
    res.status(500).json({ message: 'Could not update message' });
  }
});

// PUT /api/messages/conversation/:conversationId/read-all
router.put('/conversation/:conversationId/read-all', async (req, res) => {
  try {
    const convId = Number(req.params.conversationId);
    if (!(await isParticipant(convId, req.user.id))) return res.status(403).json({ message: 'Forbidden' });
    const [r] = await pool.query(
      "UPDATE messages SET status = 'read', read_at = NOW() WHERE conversation_id = ? AND sender_id <> ? AND status <> 'read'",
      [convId, req.user.id]
    );
    if (r.affectedRows && (await readReceiptsOn(req.user.id))) rt.emitToConversation(convId, 'messages_read', { conversationId: convId, userId: req.user.id });
    rt.emitToUser(req.user.id, 'conversation_read', { conversationId: convId });
    res.json({ updated: r.affectedRows });
  } catch (err) {
    res.status(500).json({ message: 'Could not mark messages as read' });
  }
});

// Alias kept for older clients: same as GET /api/conversations/:id/messages
router.get('/:conversationId', async (req, res) => {
  try {
    if (!(await isParticipant(req.params.conversationId, req.user.id))) return res.status(403).json({ message: 'Forbidden' });
    const limit = toInt(req.query.limit, 50, 1, 100);
    const offset = toInt(req.query.offset, 0, 0, 1000000);
    const [rows] = await pool.query(
      `${MESSAGE_SELECT} WHERE m.conversation_id = ? AND ${visible('m')} ORDER BY m.created_at DESC, m.id DESC LIMIT ? OFFSET ?`,
      [req.params.conversationId, req.user.id, limit + 1, offset]
    );
    res.json({ messages: await attachReactions(rows.slice(0, limit).reverse(), req.user.id), hasMore: rows.length > limit });
  } catch (err) {
    res.status(500).json({ message: 'Could not load messages' });
  }
});

// --- Reactions ---
router.get('/:messageId/reactions', async (req, res) => {
  try {
    const { message, error } = await accessibleMessage(req.params.messageId, req.user.id);
    if (error) return fail(res, error);
    const { reactionsFor } = require('../services/chat');
    const map = await reactionsFor([message.id], req.user.id);
    res.json(map[message.id] || []);
  } catch (err) {
    res.status(500).json({ message: 'Could not load reactions' });
  }
});

router.post('/:messageId/reactions', async (req, res) => {
  try {
    const emoji = String(req.body.emoji || '').trim();
    if (!emoji || emoji.length > 16) return res.status(400).json({ message: 'emoji required' });
    const { message, error } = await accessibleMessage(req.params.messageId, req.user.id);
    if (error) return fail(res, error);
    await pool.query('INSERT IGNORE INTO message_reactions (message_id, user_id, emoji) VALUES (?, ?, ?)', [message.id, req.user.id, emoji]);
    const [u] = await pool.query('SELECT name, avatar FROM users WHERE id = ?', [req.user.id]);
    rt.emitToConversation(message.conversation_id, 'reaction_added', {
      message_id: message.id,
      conversation_id: message.conversation_id,
      reaction: { emoji, user_id: req.user.id, user_name: u[0].name, user_avatar: u[0].avatar },
    });
    res.status(201).json({ message: 'Reaction added' });
  } catch (err) {
    res.status(500).json({ message: 'Could not add reaction' });
  }
});

router.delete('/:messageId/reactions/:emoji', async (req, res) => {
  try {
    const { message, error } = await accessibleMessage(req.params.messageId, req.user.id);
    if (error) return fail(res, error);
    const emoji = req.params.emoji;
    const [r] = await pool.query('DELETE FROM message_reactions WHERE message_id = ? AND user_id = ? AND emoji = ?', [message.id, req.user.id, emoji]);
    if (r.affectedRows) {
      rt.emitToConversation(message.conversation_id, 'reaction_removed', {
        message_id: message.id, conversation_id: message.conversation_id, user_id: req.user.id, emoji,
      });
    }
    res.json({ message: 'Reaction removed' });
  } catch (err) {
    res.status(500).json({ message: 'Could not remove reaction' });
  }
});

// --- Edit / delete (own messages only) ---
router.put('/:id', async (req, res) => {
  try {
    const content = String(req.body.content || '').trim();
    if (!content) return res.status(400).json({ message: 'content required' });
    if (content.length > 5000) return res.status(400).json({ message: 'Message is too long' });
    const { message, error } = await accessibleMessage(req.params.id, req.user.id);
    if (error) return fail(res, error);
    if (message.sender_id !== req.user.id) return res.status(403).json({ message: 'You can only edit your own messages' });
    if (message.type !== 'text') return res.status(400).json({ message: 'Only text messages can be edited' });
    await pool.query('UPDATE messages SET content = ?, edited_at = NOW() WHERE id = ?', [content, message.id]);
    const updated = await getMessage(message.id, req.user.id);
    rt.emitToConversation(message.conversation_id, 'message_edited', { message_id: message.id, conversation_id: message.conversation_id, message: updated });
    res.json(updated);
  } catch (err) {
    res.status(500).json({ message: 'Could not edit message' });
  }
});

// POST /api/messages/:id/open - recipient opens a view-once photo (works once)
router.post('/:id/open', async (req, res) => {
  try {
    const { message, error } = await accessibleMessage(req.params.id, req.user.id);
    if (error) return fail(res, error);
    const [rows] = await pool.query('SELECT sender_id, view_once, opened_at, file_url FROM messages WHERE id = ?', [message.id]);
    const m = rows[0];
    if (!m || !m.view_once) return res.status(400).json({ message: 'Not a view-once message' });
    if (m.sender_id === req.user.id) return res.status(403).json({ message: 'You cannot open your own view-once photo' });
    if (m.opened_at || !m.file_url) return res.status(410).json({ message: 'Already opened' });
    await pool.query('UPDATE messages SET opened_at = NOW() WHERE id = ? AND opened_at IS NULL', [message.id]);
    rt.emitToConversation(message.conversation_id, 'message_edited', await getMessage(message.id, req.user.id));
    res.json({ file_url: m.file_url });
  } catch (err) {
    res.status(500).json({ message: 'Could not open' });
  }
});

// --- scheduled messages ---
// POST /api/messages/schedule { conversation_id, content, send_at (ISO) }
router.post('/schedule', async (req, res) => {
  try {
    const conversationId = Number(req.body.conversation_id);
    const content = String(req.body.content || '').trim();
    const when = new Date(req.body.send_at);
    if (!conversationId || !content || isNaN(when.getTime())) return res.status(400).json({ message: 'conversation_id, content and send_at are required' });
    if (when.getTime() < Date.now() + 20 * 1000) return res.status(400).json({ message: 'Choose a time in the future' });
    if (when.getTime() > Date.now() + 365 * 86400 * 1000) return res.status(400).json({ message: 'Too far in the future' });
    if (!(await isParticipant(conversationId, req.user.id))) return res.status(403).json({ message: 'Not a participant of this conversation' });
    const [[cnt]] = await pool.query('SELECT COUNT(*) AS c FROM scheduled_messages WHERE user_id = ?', [req.user.id]);
    if (cnt.c >= 50) return res.status(400).json({ message: 'Too many scheduled messages' });
    const [r] = await pool.query('INSERT INTO scheduled_messages (user_id, conversation_id, content, send_at) VALUES (?, ?, ?, ?)', [req.user.id, conversationId, content, when]);
    res.status(201).json({ id: r.insertId, conversation_id: conversationId, content, send_at: when.toISOString() });
  } catch (err) {
    res.status(500).json({ message: 'Could not schedule message' });
  }
});

router.get('/scheduled', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT id, conversation_id, content, send_at FROM scheduled_messages WHERE user_id = ? AND conversation_id = ? ORDER BY send_at', [req.user.id, Number(req.query.conversation_id) || 0]);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: 'Could not load scheduled messages' });
  }
});

router.delete('/scheduled/:id', async (req, res) => {
  try {
    const [r] = await pool.query('DELETE FROM scheduled_messages WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
    if (!r.affectedRows) return res.status(404).json({ message: 'Not found' });
    res.json({ message: 'Removed' });
  } catch (err) {
    res.status(500).json({ message: 'Could not remove' });
  }
});

// Sends every due scheduled message (called every 30s by services/cleanup.js)
async function processScheduled() {
  const [due] = await pool.query('SELECT * FROM scheduled_messages WHERE send_at <= NOW() ORDER BY send_at LIMIT 50');
  for (const s of due) {
    const [del] = await pool.query('DELETE FROM scheduled_messages WHERE id = ?', [s.id]);
    if (!del.affectedRows) continue; // another instance took it
    try {
      if (!(await isParticipant(s.conversation_id, s.user_id)) || (await blockedInDirect(s.conversation_id, s.user_id))) continue;
      const [r] = await pool.query("INSERT INTO messages (conversation_id, sender_id, content, type, status) VALUES (?, ?, ?, 'text', 'sent')", [s.conversation_id, s.user_id, s.content]);
      await applyExpiry(r.insertId, s.conversation_id);
      const sender = await loadSender(s.user_id);
      const message = await getMessage(r.insertId, s.user_id);
      await deliver(message, sender);
    } catch (e) {
      console.warn('scheduled send:', e.message);
    }
  }
}

// DELETE /api/messages/:id?scope=me|all
//  me  - hides the message for the caller only (any message in a conversation they belong to)
//  all - removes it for everybody (own messages only)
router.delete('/:id', async (req, res) => {
  try {
    const { message, error } = await accessibleMessage(req.params.id, req.user.id);
    if (error) return fail(res, error);
    const scope = req.query.scope === 'me' ? 'me' : 'all';
    const payload = { message_id: message.id, conversation_id: message.conversation_id };
    if (scope === 'me') {
      await pool.query('INSERT IGNORE INTO message_deletions (message_id, user_id) VALUES (?, ?)', [message.id, req.user.id]);
      rt.emitToUser(req.user.id, 'message_deleted', payload);
      return res.json({ message: 'Message deleted for you' });
    }
    if (message.sender_id !== req.user.id) return res.status(403).json({ message: 'You can only delete your own messages for everyone' });
    await pool.query('DELETE FROM messages WHERE id = ?', [message.id]);
    rt.emitToConversation(message.conversation_id, 'message_deleted', payload);
    res.json({ message: 'Message deleted' });
  } catch (err) {
    res.status(500).json({ message: 'Could not delete message' });
  }
});

// POST /api/messages/:id/forward  { targets: [{ conversation_id, content? }] }
// Media is copied as-is. Text is re-sent with the `content` the client supplies (needed for end-to-end
// encrypted chats, where only the client can re-encrypt for the other conversation).
router.post('/:id/forward', async (req, res) => {
  try {
    const { message, error } = await accessibleMessage(req.params.id, req.user.id);
    if (error) return fail(res, error);
    const [rows] = await pool.query('SELECT content, type, file_url, file_name, file_size, voice_duration, voice_waveform FROM messages WHERE id = ?', [message.id]);
    const src = rows[0];
    const targets = (Array.isArray(req.body.targets) ? req.body.targets : []).slice(0, 10);
    if (!targets.length) return res.status(400).json({ message: 'No target conversations' });
    const sender = await loadSender(req.user.id);
    const sent = [];
    for (const t of targets) {
      const convId = Number(t.conversation_id);
      if (!convId || !(await isParticipant(convId, req.user.id))) continue;
      let content = src.content;
      if (src.type === 'text') {
        content = String(t.content || '').trim() || (isEncrypted(src.content) ? '' : src.content);
        if (!content) continue; // encrypted text needs a client-supplied re-encryption
      }
      const [r] = await pool.query(
        `INSERT INTO messages (conversation_id, sender_id, content, type, file_url, file_name, file_size, voice_duration, voice_waveform, status, forwarded)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'sent', 1)`,
        [convId, req.user.id, content, src.type, src.file_url, src.file_name, src.file_size, src.voice_duration, src.voice_waveform]
      );
      await applyExpiry(r.insertId, convId);
      const m = await getMessage(r.insertId, req.user.id);
      deliver(m, sender).catch((e) => console.warn('deliver:', e.message));
      sent.push(m);
    }
    res.status(201).json({ messages: sent });
  } catch (err) {
    console.error('forward:', err.message);
    res.status(500).json({ message: 'Could not forward message' });
  }
});

module.exports = router;
module.exports.processScheduled = processScheduled;
