// Run with: npm test   (no database needed)
const test = require('node:test');
const assert = require('node:assert');

// db.js opens a pool lazily; mock it so the helpers can be required without MySQL
const Module = require('module');
const origLoad = Module._load;
Module._load = function (request, ...rest) {
  if (request === '../db' || request.endsWith('/db')) return { query: async () => [[]] };
  if (request === '../services/notify') return { notify: async () => {} };
  return origLoad.call(this, request, ...rest);
};

const { extractMentions, extractHashtags } = require('../utils/mentions');
const { notBlocked } = require('../utils/blocks');
const { toInt } = require('../utils/format');

test('mentions: finds unique @usernames, ignores emails', () => {
  assert.deepStrictEqual(extractMentions('hi @Ahmed_1 and @sara, mail me a@b.com @Ahmed_1'), ['ahmed_1', 'sara']);
});

test('hashtags: unicode tags, lowercased, no duplicates, not inside words', () => {
  assert.deepStrictEqual(extractHashtags('#Hello #مرحبا #hello a#b #x'), ['hello', 'مرحبا']);
});

test('notBlocked: one placeholder, column used consistently', () => {
  const sql = notBlocked('p.user_id');
  assert.strictEqual((sql.match(/\?/g) || []).length, 1);
  assert.ok(sql.includes('p.user_id'));
});

test('toInt clamps and falls back', () => {
  assert.strictEqual(toInt('abc', 5, 1, 10), 5);
  assert.strictEqual(toInt('99', 5, 1, 10), 10);
  assert.strictEqual(toInt('-4', 5, 1, 10), 1);
});

// The block check relies on: ids of a blocked pair sum to (target + viewer) and one of them is the target.
test('block sum trick is symmetric and has no false positives', () => {
  const hit = (blocker, blocked, target, viewer) => blocker + blocked === target + viewer && (blocker === target || blocked === target);
  assert.ok(hit(5, 9, 5, 9));   // viewer 9 blocked by 5 (target)
  assert.ok(hit(9, 5, 5, 9));   // viewer 9 blocked target 5
  for (let a = 1; a < 12; a++) for (let b = 1; b < 12; b++) for (let t = 1; t < 12; t++) for (let v = 1; v < 12; v++) {
    if (hit(a, b, t, v)) assert.ok((a === t && b === v) || (a === v && b === t) || (a === t && b === v));
  }
});

const { parse, inQuiet } = require('../services/prefs');

test('prefs: defaults and quiet hours (overnight window, timezone offset)', () => {
  const p = parse(null);
  assert.strictEqual(p.notif.message, true);
  const q = { enabled: true, start: 22, end: 7, tz: 120 }; // phone is UTC+2
  assert.strictEqual(inQuiet(q, new Date('2026-01-01T21:00:00Z')), true);  // 23:00 local
  assert.strictEqual(inQuiet(q, new Date('2026-01-01T06:00:00Z')), false); // 08:00 local
  assert.strictEqual(inQuiet(q, new Date('2026-01-01T03:00:00Z')), true);  // 05:00 local
  assert.strictEqual(inQuiet({ ...q, enabled: false }, new Date('2026-01-01T21:00:00Z')), false);
});
